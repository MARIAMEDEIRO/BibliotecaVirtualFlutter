package br.com.biblioteca.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
